package HospitalManagementSystem;

//Team members- N.Niharika
//roll no.- 23011101083
//coded by- N.Niharika


//User.java
interface User {
 String getName();
 int getID();
}
