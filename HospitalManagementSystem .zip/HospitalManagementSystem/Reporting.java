package HospitalManagementSystem;

//Reporting.java
public interface Reporting {
 void generateReport();
}