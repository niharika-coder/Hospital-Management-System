package HospitalManagementSystem;

//Scheduling.java
public interface Scheduling {
 void scheduleAppointment(Patient patient, Doctor doctor) throws SchedulingException;
}
