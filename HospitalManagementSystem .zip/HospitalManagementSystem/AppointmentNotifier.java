package HospitalManagementSystem;

//AppointmentNotifier.java
public class AppointmentNotifier extends Thread {
 private Patient patient;
 private Doctor doctor;

 public AppointmentNotifier(Patient patient, Doctor doctor) {
     this.patient = patient;
     this.doctor = doctor;
 }

 @Override
 public void run() {
     try {
         Thread.sleep(2000); // Simulating notification delay
         System.out.println("Reminder: " + patient.getName() + " has an appointment with Dr. " + doctor.getName());
     } catch (InterruptedException e) {
         System.err.println("Notification interrupted: " + e.getMessage());
     }
 }
}

