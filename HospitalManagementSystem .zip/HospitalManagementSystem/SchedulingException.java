package HospitalManagementSystem;

//SchedulingException.java
public class SchedulingException extends Exception {
 public SchedulingException(String message) {
     super(message);
 }
}
