package HospitalManagementSystem;

//Doctor.java
class Doctor implements User {
private String name;
private int id;

public Doctor(String name, int id) {
   this.name = name;
   this.id = id;
}

@Override
public String getName() {
   return name;
}

@Override
public int getID() {
   return id;
}
}
