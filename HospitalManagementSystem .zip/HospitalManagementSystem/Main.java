package HospitalManagementSystem;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HospitalManagement system = new HospitalManagement();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        System.out.println("Welcome to the Hospital Management System");

        while (!exit) {
            System.out.println("\nPlease select an option:");
            System.out.println("1. Add Patient");
            System.out.println("2. Add Doctor");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. Generate Bill");
            System.out.println("5. Generate Report");
            System.out.println("6. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter patient name: ");
                    String patientName = scanner.nextLine();
                    System.out.print("Enter patient ID: ");
                    int patientId = scanner.nextInt();
                    Patient patient = new Patient(patientName, patientId);
                    system.addPatient(patient);
                    System.out.println("Patient added successfully.");
                    break;

                case 2:
                    System.out.print("Enter doctor name: ");
                    String doctorName = scanner.nextLine();
                    System.out.print("Enter doctor ID: ");
                    int doctorId = scanner.nextInt();
                    Doctor doctor = new Doctor(doctorName, doctorId);
                    system.addDoctor(doctor);
                    System.out.println("Doctor added successfully.");
                    break;

                case 3:
                    System.out.print("Enter patient ID for appointment: ");
                    int pId = scanner.nextInt();
                    System.out.print("Enter doctor ID for appointment: ");
                    int dId = scanner.nextInt();

                    // Find patient and doctor by ID
                    Patient selectedPatient = system.getPatientById(pId);
                    Doctor selectedDoctor = system.getDoctorById(dId);

                    if (selectedPatient != null && selectedDoctor != null) {
                        try {
                            system.scheduleAppointment(selectedPatient, selectedDoctor);
                            new AppointmentNotifier(selectedPatient, selectedDoctor).start();
                        } catch (SchedulingException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    } else {
                        System.out.println("Invalid patient or doctor ID.");
                    }
                    break;

                case 4:
                    System.out.print("Enter patient ID for billing: ");
                    int billPatientId = scanner.nextInt();
                    System.out.print("Enter bill amount: ");
                    double amount = scanner.nextDouble();

                    Patient billPatient = system.getPatientById(billPatientId);
                    if (billPatient != null) {
                        system.generateBill(billPatient, amount);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;

                case 5:
                    system.generateReport();
                    break;

                case 6:
                    exit = true;
                    System.out.println("Exiting the system. Thank you!");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
