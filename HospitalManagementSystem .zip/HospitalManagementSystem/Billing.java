package HospitalManagementSystem;

//Billing.java
public interface Billing {
 void generateBill(Patient patient, double amount);
}
