package HospitalManagementSystem;

//HospitalManagementSystem.java
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HospitalManagement implements Scheduling, Billing, Reporting {
 // Lists to store patients and doctors
 protected List<Patient> patients = new ArrayList<>();
 protected List<Doctor> doctors = new ArrayList<>();
 
//Method to add a patient to the system
 public void addPatient(Patient patient) {
     patients.add(patient);
 }

 // Method to add a doctor to the system
 public void addDoctor(Doctor doctor) {
     doctors.add(doctor);
 }
//In HospitalManagementSystem.java

//Method to find a patient by their ID
public Patient getPatientById(int id) {
  for (Patient patient : patients) {
      if (patient.getID() == id) {
          return patient;
      }
  }
  return null; // Return null if no patient with the given ID is found
}

//Method to find a doctor by their ID
public Doctor getDoctorById(int id) {
  for (Doctor doctor : doctors) {
      if (doctor.getID() == id) {
          return doctor;
      }
  }
  return null; // Return null if no doctor with the given ID is found
}

 
 // Map to store appointments
 private Map<Patient, Doctor> appointments = new HashMap<>();


 @Override
 public void scheduleAppointment(Patient patient, Doctor doctor) throws SchedulingException {
     if (appointments.containsKey(patient)) {
         throw new SchedulingException("Appointment already scheduled for this patient.");
     }
     appointments.put(patient, doctor);
     System.out.println("Appointment scheduled for " + patient.getName() + " with Dr. " + doctor.getName());
 }

 @Override
 public void generateBill(Patient patient, double amount) {
     System.out.println("Generating bill for patient: " + patient.getName() + " - Amount: $" + amount);
     String billData = "Patient ID: " + patient.getID() + "\nPatient Name: " + patient.getName() + "\nBill Amount: $" + amount;
     saveToFile("Billing_" + patient.getID() + ".txt", billData);
 }

 @Override
 public void generateReport() {
     System.out.println("Generating report of all scheduled appointments...");
     appointments.forEach((patient, doctor) -> 
         System.out.println("Patient: " + patient.getName() + " (ID: " + patient.getID() + ") - " +
                            "Doctor: " + doctor.getName() + " (ID: " + doctor.getID() + ")")
     );
 }


 // Helper method to save data to a file
 private void saveToFile(String filename, String data) {
     try (FileWriter writer = new FileWriter(filename)) {
         writer.write(data);
     } catch (IOException e) {
         System.err.println("Error saving file: " + e.getMessage());
     }
 }
}

